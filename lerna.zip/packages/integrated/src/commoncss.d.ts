declare const css: () => void;
export default css;
//# sourceMappingURL=commoncss.d.ts.map
