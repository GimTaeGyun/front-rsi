export const validation = () => {
  return false;
};
