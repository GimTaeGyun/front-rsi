import React from 'react';

const Media = () => {
  return <></>;
};

export default Media;
