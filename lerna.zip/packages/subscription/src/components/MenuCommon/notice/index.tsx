import React from 'react';

const Notice = () => {
  return <></>;
};

export default Notice;
