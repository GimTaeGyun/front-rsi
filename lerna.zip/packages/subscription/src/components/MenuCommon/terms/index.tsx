import React from 'react';

const Terms = () => {
  return <></>;
};

export default Terms;
