import React from 'react';

const Contract = () => {
  return <></>;
};

export default Contract;
