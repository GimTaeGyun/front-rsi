import React, { useEffect,useState } from 'react';

const Pay = () => {
  return <></>;
};

export default Pay;
