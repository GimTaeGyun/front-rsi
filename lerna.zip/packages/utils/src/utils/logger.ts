const logger = (msg: string) => {
  console.log(msg);
};

export default logger;
